import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { selectUser } from "../../features/userSlice";
import "./Navbar.css";
import { FiSearch } from "react-icons/fi";
import { GiHamburgerMenu } from "react-icons/gi";

const NavBar = () => {
  const [show, handleShow] = useState(false);
  const user = useSelector(selectUser);
  const [isOpen, setIsOpen] = useState(true);
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };
  const transitionNavbar = () => {
    // console.log(window.scrollY);
    if (window.scrollY > 100) {
      handleShow(true);
    } else {
      handleShow(false);
    }
  };
  useEffect(() => {
    window.addEventListener("scroll", transitionNavbar);
    return () => window.removeEventListener("scroll", transitionNavbar);
  }, []);

  return (
    <>
      <div className={`nav ${show && "nav__black"}`}>
        <ul className="nav__contents">
          <li>
            <Link to="/">
              <img
                className="nav__logo"
                src="https://upload.wikimedia.org/wikipedia/commons/7/7a/Logonetflix.png"
                alt=""
              />
            </Link>
          </li>
          <li className="nav__hamMenu" onClick={toggleMenu}>
            <GiHamburgerMenu />
          </li>
          {user ? (
            <>
              <li className="nav__search">
                <Link to="/search">
                  <FiSearch />
                </Link>
              </li>

              {isOpen && (
                <div className="hamburgar-menu">
                  <li>
                    <Link to="/">Home</Link>
                  </li>
                  <li>
                    <Link to="/tv-shows">Tv Shows</Link>
                  </li>
                  <li>
                    <Link to="/movie-shows">Movies</Link>
                  </li>
                  <li>
                    <Link to="/popular">New & Popular</Link>
                  </li>
                  <li>
                    <Link to="/wishlist">My List</Link>
                  </li>
                </div>
              )}
              <li>
                <Link to="/profile">
                  <img
                    className="nav__avatar"
                    src="https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png"
                    alt="avatar"
                  />
                </Link>
              </li>
            </>
          ) : (
            <Link to="/">
              <button className="nav__button">Sign In</button>
            </Link>
          )}
        </ul>
      </div>
    </>
  );
};

export default NavBar;

// import React, { useEffect, useState } from "react";
// import { useSelector } from "react-redux";
// import { Link } from "react-router-dom";
// import { selectUser } from "../../features/userSlice";
// import "./Navbar.css";
// import { FiSearch } from "react-icons/fi";
// import { GiHamburgerMenu } from "react-icons/gi";
// const NavBar = () => {
//   const [show, handleShow] = useState(false);
//   const user = useSelector(selectUser);
//   const [isOpen, setIsOpen] = useState(true);
//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };
//   const transitionNavbar = () => {
//     // console.log(window.scrollY);
//     if (window.scrollY > 100) {
//       handleShow(true);
//     } else {
//       handleShow(false);
//     }
//   };
//   useEffect(() => {
//     window.addEventListener("scroll", transitionNavbar);
//     return () => window.removeEventListener("scroll", transitionNavbar);
//   }, []);
//   return (
//     <>
//       <div className={`nav ${show && "nav__black"}`}>
//         <ul className="nav__contents">
//           {/* <div className="menu-nav"> */}
//           {/* <ul class="menu-nav-items"> */}
//           <li>
//             <Link to="/">
//               <img
//                 className="nav__logo"
//                 src="https://upload.wikimedia.org/wikipedia/commons/7/7a/Logonetflix.png"
//                 alt=""
//               />
//             </Link>
//           </li>
//           <li className="nav__hamMenu" onClick={toggleMenu}>
//             <GiHamburgerMenu />
//           </li>
//           {user ? (
//             <>
//               <li className="nav__search">
//                 <Link to="/search">
//                   <FiSearch />
//                 </Link>
//               </li>

//               {isOpen && (
//                 <>
//                   <div className="hamburgar-menu">
//                     <li>
//                       <Link to="/">Home</Link>
//                     </li>
//                     <li>
//                       <Link to="/tv-shows">Tv Shows</Link>
//                     </li>
//                     <li>
//                       <Link to="/movie-shows">Movies</Link>
//                     </li>
//                     <li>
//                       <Link to="/popular">New & Popular</Link>
//                     </li>
//                     <li>
//                       <Link to="/wishlist">My List</Link>
//                     </li>
//                     {/* <li>
//                       <Link to="/category">Category</Link>
//                     </li> */}
//                   </div>
//                 </>
//               )}
//               <li>
//                 <Link to="/profile">
//                   <img
//                     className="nav__avatar"
//                     src="https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png"
//                     alt="avatar"
//                   />
//                 </Link>
//               </li>
//             </>
//           ) : (
//             <>
//               <Link to="/">
//                 <button className="nav__button">Sign In</button>
//               </Link>
//             </>
//           )}
//           {/* </ul> */}
//           {/* </div> */}
//         </ul>
//       </div>
//     </>
//   );
// };
// export default NavBar;
