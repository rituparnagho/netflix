import React from "react";
import "./Category.css";

const Category = () => {
  return (
    <div>
      <h1>Category</h1>
    </div>
  );
};

export default Category;
